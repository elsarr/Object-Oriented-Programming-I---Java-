
public class PoS 
{
	
	//2 attributes : type sales and array of type PrePaiCard
	
	//object of type Sales
	private Sales objSales;
	
	//array of objects of type PrepaiCard
	private PrePaiCard[] objPPC;
	
	
	//default constructor 
	public PoS()
	{
		objSales = null;
		objPPC = null;
	}
	
	//constructor with 2 parameters to set the initial value of each attribute 
	public PoS(Sales obj1, PrePaiCard[] obj2)
	{
		objSales = obj1;
	    
	    if (obj2.length == 0) 
	    {
	        objPPC = new PrePaiCard[0]; // Initialize objPPC with an empty array
	    } 
	    else 
	    {
	        objPPC = obj2;
	    }
	}
	
	//method that returns true if the total value of sales of 2 PoS objects are equal and false otherwise
	public boolean equalSales(PoS n1)
	{
		
		if (this.objSales.SalesTotal() == n1.objSales.SalesTotal())
			return true;
		else
			return false;
	}
	
	//method that returns true if the number of each sales category of 2 PoS objects are equal and false otherwise
	public boolean equalCategory(PoS n1)
	{
		return (this.objSales.equals(n1.objSales));
			
		//if (n1.objSales.getNumberCountJunior() == this.objSales.getNumberCountJunior() && n1.objSales.getNumberCountTeen() == this.objSales.getNumberCountTeen() && n1.objSales.getNumberCountMedium() == this.objSales.getNumberCountMedium() && n1.objSales.getNumberCountBig() == this.objSales.getNumberCountBig() && n1.objSales.getNumberCountFamily() == this.objSales.getNumberCountFamily())
			
	}
	
	//method that returns the total dollar value of sales of a PoS
	public int getTotal()
	{
		return this.objSales.SalesTotal();
	}
	
	//method that returns the number of prepaid cards in a PoS
	public int getNumberPPC()
	{
		return this.objPPC.length;
	}
	
	//method that adds a new PrePaiCard to the PoS and returns the number of pre-paid cards of a PoS after the addition
	public int addPPC(PrePaiCard n1)
	{
		if (objPPC == null) 
		{
            objPPC = new PrePaiCard[1];
            objPPC[0] = n1;
        } 
		else
		{
            PrePaiCard[] temp = new PrePaiCard[objPPC.length + 1];
            for (int i = 0; i < objPPC.length; i++) 
            {
                temp[i] = objPPC[i];
            }
            temp[objPPC.length] = n1;
            objPPC = temp;
        }
        return objPPC.length;
	}
	
	//method that removes a pre-paid card from the PoS and returns true if the removal of the card was successful 
	public boolean removePPC(int index)
	{
		if (objPPC == null || objPPC.length == 0) 
		{
	        return false; // Invalid input
	    }

	    
	    PrePaiCard[] temp = new PrePaiCard[objPPC.length - 1];
	    int tempIndex = 0;

	    for (int i = 0; i < objPPC.length; i++) 
	    {
	        if (i != index) 
	        {
	            temp[tempIndex++] = objPPC[i]; // Copy elements except the one at the specified index
	        }
	    }

	    objPPC = temp; // Update reference to the new array
	    return true; // Successfully removed the card
	
	}
		
	
	//method that updates the expiry day and month of a prepaid card 
	public void updateExpiryDate(int day, int month, int index)
	{
		for(int i = 0; i<this.objPPC.length;i++)
		{
				this.objPPC[index].setExpiryDay(day);
				this.objPPC[index].setExpiryMonth(month);
			
		}
		
	}
	
	//method that adds meals sales to the PoS and returns the new total sales value payments of the PoS
	public String NewTotalMealSales(int juniorNum, int teenNum, int mediumNum, int bigNum, int familyNum)
	{
		
		objSales.changeNumberCountJunior(objSales.getNumberCountJunior() + juniorNum);
		objSales.changeNumberCountTeen(objSales.getNumberCountTeen() + teenNum);
		objSales.changeNumberCountMedium(objSales.getNumberCountMedium() + mediumNum);
		objSales.changeNumberCountBig(objSales.getNumberCountBig() + bigNum);
		objSales.changeNumberCountFamily(objSales.getNumberCountFamily() + familyNum);
		
		double j = objSales.getNumberCountJunior()*objSales.getCostJunior();
		double t = objSales.getNumberCountTeen()*objSales.getCostTeen();
		double m = objSales.getNumberCountMedium()*objSales.getCostMedium();
		double b = objSales.getNumberCountBig()*objSales.getCostBig();
		double f = objSales.getNumberCountFamily()*objSales.getCostFamily();
		double t1 = j + t + m + b + f;
		
		return ("You now have $" + t1); 
	}
	
	//method that returns true if the total sales value and the number of pre-paid card of 2 PoS objects are equal
	public boolean equals(PoS n)
	{
		if (this.objPPC == null && n.objPPC == null) {
	        // If both objPPC arrays are null, consider them equal
	        return true;
	    }
		else if (this.objPPC == null || n.objPPC == null) 
	        // If only one objPPC array is null, they are not equal
	        return false;
	    else if (this.getNumberPPC() == n.getNumberPPC() && this.getTotal() == n.getTotal())
			return true;
		else
			return false;
	}
	
	//method that returns a string indicating the number of each meal sales category as well as the details of each pre-paid card of the PoS
	public String toString()
	{
		String one = "" + objSales.getNumberCountJunior() + " x " + "$" + objSales.getCostJunior()
				+ " + " + objSales.getNumberCountTeen() + " x " + "$" + objSales.getCostTeen() 
				+ " + " + objSales.getNumberCountMedium() + " x " + "$" + objSales.getCostMedium()
				+ " + " + objSales.getNumberCountBig() + " x " + "$" + objSales.getCostBig()
				+ " + " + objSales.getNumberCountFamily() + " x " + "$" + objSales.getCostFamily();
				   
		String j = "";
		if(objPPC == null || objPPC.length ==0)
		{
			return (one + "\n" + "No PrePaiCards");
		}
		else
		{
			for (int i = 0; i<objPPC.length;i++)
			{
				j += (objPPC[i].toString() + "\n");
			}
			return (one + "\n" + j);
		}
		
	}
	
	//method that returns a string with the breakdown of the sales 
	public String SalesBreakdown()
	{
		String one =	"" + objSales.getNumberCountJunior() + " x " + "$" + objSales.getCostJunior()
		+ " + " + objSales.getNumberCountTeen() + " x " + "$" + objSales.getCostTeen() 
		+ " + " + objSales.getNumberCountMedium() + " x " + "$" + objSales.getCostMedium()
		+ " + " + objSales.getNumberCountBig() + " x " + "$" + objSales.getCostBig()
		+ " + " + objSales.getNumberCountFamily() + " x " + "$" + objSales.getCostFamily();
		
		return one;
	}
	
}
