
public class PrePaiCard 
{
	//attributes 
	private String diet; 
	
	private String ID;

	private int expiryDay;
	private int expiryMonth;
	
	//default constructor 
	public PrePaiCard()
	{
		diet = null;
		ID = "";
		expiryDay = 0;
		expiryMonth = 0;
	}
	
	//custom constructor with 4 parameters to set the initial value of each attribute
	public PrePaiCard(String diet, String ID, int day, int month)
	{
		if (day<1 || day>31)
			day = 0;
		if (month<1 || month>12)
			month = 0;
		
		this.diet = diet;
		this.ID = ID;
		this.expiryDay = day;
		this.expiryMonth = month;
	}
	
	//copy constructor with one parameter 
	public PrePaiCard(PrePaiCard n)
	{
		this.diet = n.diet;
		this.ID = n.ID;
		this.expiryDay = n.expiryDay;
		this.expiryMonth = n.expiryMonth;
	}
	

	//accessor methods for all 4 attributes
	public String getDiet()
	{
		return this.diet;
	}
	
	public String getID()
	{
		return this.ID;
	}
	
	public int getExpiryDay()
	{
		return this.expiryDay;
	}
	
	public int getExpiryMonth()
	{
		return this.expiryMonth;
	}
	
	public String getExpiryDate()
	{
		String dd = "";
		String mm = "";
		
		if (this.expiryDay < 10)
			dd = "0"+ this.expiryDay;
		else
			dd = ""+ this.expiryDay;
		
		if (this.expiryMonth < 10)
			mm = "0"+ this.expiryMonth;
		else
			mm = ""+ this.expiryMonth;
		
		return(dd+"/"+mm);
	}
	
	//mutator methods
	public void setExpiryDay(int d)
	{
		if (d<1 || d>31)
			this.expiryDay = 0;
		else
			this.expiryDay = d;
		
	}
	
	public void setExpiryMonth(int m)
	{
		if (m<1 || m>12)
			this.expiryMonth = 0;
		else
			this.expiryMonth = m;
	}
	
	//method that returns a string indicating the type of pre-paid card, the ID number, and the due date in a dd/mm format
	public String toString()
	{
		return(this.diet + " - " + getID() + " - " + getExpiryDate() + ".");
	}
	
	//method that returns true if 2 objects of type PrePaiCard are identical and have the same information and false otherwise
	public boolean equals(PrePaiCard obj1)
	{
		if (this.getDiet() == obj1.getDiet() && obj1.getExpiryDay() == this.getExpiryDay() && obj1.getExpiryMonth() == this.getExpiryMonth() && obj1.getID() == this.getID())
			return true;
		else
			return false;
	}
}
