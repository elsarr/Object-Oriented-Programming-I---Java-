
public class Sales 
{
	
		
	//instance attributes that counts the numbers of meals 
	private int numberCountJunior;
	private int numberCountTeen;
	private int numberCountMedium;
	private int numberCountBig;
	private int numberCountFamily;
	
	//initialize final constant static attributes that set the prices of meals 
	private static final int costJunior = 5;
	private static final int costTeen = 10;
	private static final int costMedium = 12;
	private static final int costBig = 15;
	private static final int costFamily = 20;
	
	
	//default constructor - initialize values 
	public Sales()
	{
		this.numberCountJunior = 0;
		this.numberCountTeen = 0;
		this.numberCountMedium = 0;
		this.numberCountBig = 0;
		this.numberCountFamily = 0;
		
	}
	
	//custom constructor with 5 integer parameters to set the number of each meal category
	public Sales(int Junior, int Teen, int Medium, int Big, int Family)
	{
		this.numberCountJunior = Junior;
		this.numberCountTeen = Teen;
		this.numberCountMedium = Medium;
		this.numberCountBig = Big;
		this.numberCountFamily = Family;
		
	}
	
	//copy constructor with one parameter of type sales  
	public Sales(Sales number)
	{
		this.numberCountJunior = number.numberCountJunior;
		this.numberCountTeen = number.numberCountTeen;
		this.numberCountMedium = number.numberCountMedium;
		this.numberCountBig = number.numberCountBig;
		this.numberCountFamily = number.numberCountFamily;
		
	}
	
	//accessor methods for all attributes 
	public int getNumberCountJunior()
	{
		return this.numberCountJunior;
	}
	
	public int getNumberCountTeen()
	{
		return this.numberCountTeen;
	}
	
	public int getNumberCountMedium()
	{
		return this.numberCountMedium;
	}
	
	public int getNumberCountBig()
	{
		return this.numberCountBig;
	}
	
	public int getNumberCountFamily()
	{
		return this.numberCountFamily;
	}
	
	public int getCostJunior()
	{
		return costJunior; 
	}
	
	public int getCostTeen()
	{
		return costTeen; 
	}
	
	public int getCostMedium()
	{
		return costMedium; 
	}
	
	public int getCostBig()
	{
		return costBig; 
	}
	
	public int getCostFamily()
	{
		return costFamily;  
	}
	
	
	//mutator methods for all attributes 
	public void changeNumberCountJunior(int n)
	{		
		this.numberCountJunior = n;
	}
	
	public void changeNumberCountTeen(int n)
	{
		this.numberCountTeen = n;		
	}
	
	public void changeNumberCountMedium(int n)
	{
		this.numberCountMedium = n; 
		
	}
	
	public void changeNumberCountBig(int n)
	{
		this.numberCountBig = n;
		
	}
	
	public void changeNumberCountFamily(int n)
	{
		this.numberCountFamily = n;
		
	}
	
		
	
	//method with 5 integer parameters which increases the number of each meal category by the indicated number
	public void addSales(int addJunior, int addTeen, int addMedium, int addBig, int addFamily)
	{
		this.numberCountJunior += addJunior;
		this.numberCountTeen += addTeen;
		this.numberCountMedium += addMedium;
		this.numberCountBig += addBig;
		this.numberCountFamily += addFamily;
		
	}
	
	//method that returns an integer indicating the total value of the sales in PoS
	public int SalesTotal()
	{
		int junior = numberCountJunior * costJunior;
		int teen = numberCountTeen * costTeen;
		int medium = numberCountMedium * costMedium;
		int big = numberCountBig * costBig;
		int family = numberCountFamily * costFamily;
		int totalSales = junior + teen + medium + big + family;
		return totalSales;
	}
	
	//method that returns a string indicating the count of each meal
	public String toString()
	{
		return (numberCountJunior + " x " + "$" + costJunior
				+ " + " + numberCountTeen + " x " + "$" + costTeen 
				+ " + " + numberCountMedium + " x " + "$" + costMedium  
				+ " + " + numberCountBig + " x " + "$" + costBig
				+ " + " + numberCountFamily + " x " + "$" + costFamily);
		
	}
	
	//method which returns true if the 2 objects of type sales have the same breakdown of meal category and false otherwise
	public boolean equals(Sales obj1)
	{
		boolean value;
		if (obj1.numberCountJunior == this.numberCountJunior && obj1.numberCountTeen == this.numberCountTeen && obj1.numberCountMedium == this.numberCountMedium && obj1.numberCountBig == this.numberCountBig && obj1.numberCountFamily == this.numberCountFamily)
		{
			value = true;
		}
		else
		{
			value = false;
		}
		return value;
	}
	
}
