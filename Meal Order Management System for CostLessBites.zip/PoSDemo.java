//--------------------------------------------
// Assignment 4
// Written by : Elsa Rufenacht  
// For COMP 248 Section S - Fall 2023
//--------------------------------------------


/* This program manages the orders of a catering service where people can order meals using either
 * their money or prepaid meal cards. There are five meal categories: junior, teen, medium, big, family, each with flat prices.
 * And there's six diet menus: carnivore, halal, kosher, pescatarian, vegetarian, vegan. 
 * Prepeird cards are sold by diet type.
 * The Sales class keeps track of the number of sales sold on-demand. 
 * The PrePaiCard class keeps track of the type of card based on diet, ID, expiry date.
 * The PoS class contains Sales and PrePaiCards.
 * PoS demo is the driver class.
 */

import java.util.Scanner;

public class PoSDemo 
{

	public static void main(String[] args) 
	{
		Sales a = new Sales(2,1,0,4,1);
		PrePaiCard a1 = new PrePaiCard("Vegetarian","40825164",25,12);
		PrePaiCard a2 = new PrePaiCard("Carnivore","21703195",3,12);
		PrePaiCard[] aa = {a1,a2};
		
		Sales b = new Sales(2,1,0,4,1);
		PrePaiCard b1 = new PrePaiCard("Vigan","40825164",7,12);
		PrePaiCard b2 = new PrePaiCard("Vegetarian", "21596387",24,8);
		PrePaiCard[] bb = {b1,b2};
		
		Sales c = new Sales(0,1,5,2,0);
		PrePaiCard c1 = new PrePaiCard("Pescatarian","95432806",1,6);
		PrePaiCard c2 = new PrePaiCard("Halal", "42087913",18,12);
		PrePaiCard c3 = new PrePaiCard("Kosher", "40735421",5,4);
		PrePaiCard[] cc = {c1,c2,c3};
		
		Sales d = new Sales(3,2,4,1,2);
		PrePaiCard[] dd = {};
		
		Sales e = new Sales(3,2,4,1,2);
		PrePaiCard[] ee = {};
		
		PoS[] arr1 = new PoS[5];
		arr1[0] = new PoS(a, aa);
		arr1[1] = new PoS(b,bb);
		arr1[2] = new PoS(c,cc);
		arr1[3] = new PoS(d,dd);
		arr1[4] = new PoS(e,ee);
		
		
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("| Welcome to Concordia CostLessBites Catering Sales Counter Application         |");
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		//menu
		
		Scanner in = new Scanner(System.in);
		int userInput = 0;
		
		do
		{
			do
			{
				System.out.println("| What would you like to do?");
				System.out.println("| 1  >> See the content of all PoSs                                             |");
				System.out.println("| 2  >> See the content of one PoS                                              |");
				System.out.println("| 3  >> List PoSs with same $ amount of sales                                   |");
				System.out.println("| 4  >> List PoSs with same number of Sales categories                          |");
				System.out.println("| 5  >> List PoSs with same $ amount of Sales and same number of prpaid cards   |");
				System.out.println("| 6  >> Add a PrePaiCard to an existing PoS                                     |");
				System.out.println("| 7  >> Remove an existing prepaid card from a PoS                              |");
				System.out.println("| 8  >> Update the expiry date of an existing Prepaid card                      |");
				System.out.println("| 9  >> Add Sales to a PoS                                                      |");
				System.out.println("| 0  >> To quit                                                                 |");
				System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
				System.out.println();
				
				System.out.print("Please enter your choice and press <Enter>:");
				userInput = in.nextInt();
				
				if (userInput <= 0 || userInput >9)
				{
					if (userInput == 0)
						break;
					System.out.println("Sorry that is not a valid choice. Try again.");
				}
			}
			while(userInput < 1 || userInput >9);
			
			
				
			if (userInput == 1) //displays the sales categories and prepaid cards of each PoS
			{
				System.out.println("Content of each PoS:");
				System.out.println("---------------------");
					
				for(int i = 0; i<arr1.length;i++)
				{
					System.out.println("PoS #"+i+":");
					System.out.println(arr1[i].toString());
					System.out.println();
				}		
			}
			else if (userInput == 2) //asks which PoS the user wishes to see the content of and display the categories of the sales and prepaid cards info
			{
				
				System.out.print("Which PoS do you want to see the content of? (Enter number 0 to " + (arr1.length-1) + "): ");
				int next = in.nextInt();
					
				do
				{
					if (next <0 || next >(arr1.length-1))
					{
						System.out.println("Sorry there is no PoS number " + next);
						System.out.print("--> Try again: Enter number 0 to " + (arr1.length-1) + "): ");
						next = in.nextInt();	
					}
				}
				while(next <0 || next >(arr1.length-1));
				
				System.out.println(arr1[next].toString());
				System.out.println();
				
			}
			else if (userInput == 3) //compares all PoSs and displays the pairs that have the same total amount of sales
			{
				System.out.println("List of PoSs with same total $ Sales:");
				System.out.println();
				
				
				for (int i = 0; i < arr1.length - 1; i++) 
				{
				    for (int j = i + 1; j < arr1.length; j++) 
				    {
				        if (arr1[i].equalSales(arr1[j])) 
				        {
				            System.out.println("\t PoSs " + i + " and " + j + " both have " + arr1[i].getTotal());
				        }
				    }
				}
				System.out.println();
			}
			else if (userInput == 4) //compares all PoSs and displays the pairs that have the same total amount distribution 
			{
				System.out.println("List of PoSs with same Sales categories:");
				System.out.println();
				
				for (int i = 0; i < arr1.length - 1; i++) 
				{
				    for (int j = i + 1; j < arr1.length; j++) 
				    {
				        if (arr1[i].equalCategory(arr1[j])) 
				        {
				            System.out.println("\t PoSs " + i + " and " + j + " both have " + arr1[i].SalesBreakdown());
				        }
				    }
				}
				System.out.println();
			}
			else if(userInput == 5)//lists all pairs that are equal based on the definition of equal in class PoS
			{
				System.out.println("List of PoSs with same $ amount of sales and same number of PrePaiCards :");
				System.out.println();
				
				for (int i = 0; i < arr1.length - 1; i++) 
				{
				    for (int j = i + 1; j < arr1.length; j++) 
				    {
				        if (arr1[i].equals(arr1[j])) 
				        {
				            System.out.println("\t PoSs " + i + " and " + j);
				        }
				    }
				}
				System.out.println();
			}
			else if (userInput == 6)//asks the user which PoS they want to add a prepaid card to, as well as the information. create new prepaidcard and add it to the PoS in question
			{
				System.out.print("Which PoS do you want to add a PrePaiCard to? (Enter number 0 to " + (arr1.length-1) + "): ");
				int next = in.nextInt();
				
				do
				{
					if (next <0 || next >(arr1.length-1))
					{
						System.out.print("--> Try again: (Enter number 0 to " + (arr1.length-1) + "): ");
						next = in.nextInt();	
					}
				}
				while(next <0 || next >(arr1.length-1));
				
				System.out.println("Please enter the following information so that we may complete the PrePaiCard -");
				System.out.println("--> Type of PrePaiCard (Carnivore, Halal, Kosher, Pescatarian, Vegetarian, Vigan):");
				String diet = in.next();
				
				System.out.print("--> Id of the prepaid card owner: ");
				String id = in.next();
				
				System.out.print("--> Expiry day number and month (separate by a space): ");
				int day = in.nextInt();
				int month = in.nextInt();
				
				
				PrePaiCard newCard = new PrePaiCard(diet,id,day,month);
				System.out.println("You now have " + arr1[next].addPPC(newCard) + " PrePaiCard");
			}
			else if (userInput == 7) //asks the user which PoS they want to remove a prepaid card from and remove it from the PoS
			{
				System.out.print("Which PoS do you want to remove a PrePaiCard from? (Enter number 0 to " + (arr1.length-1) + "): ");
				int posNumber = in.nextInt();
				do
				{
					if (posNumber <0 || posNumber >(arr1.length-1))
					{
							System.out.print("--> Try again: (Enter number 0 to " + (arr1.length-1) + "): ");
							posNumber = in.nextInt();	
					}
				}
				while(posNumber <0 || posNumber >(arr1.length-1));
				
				if(arr1[posNumber].getNumberPPC() == 0 || arr1 == null)
				{
					System.out.println("Sorry that PoS has no PrePaiCards");
				}
				else
				{				
					System.out.println("(Enter number 0 to " + (arr1[posNumber].getNumberPPC()-1) + "): ");
					int index = in.nextInt();
					
					do
					{
						if (index <0 || index >(arr1[posNumber].getNumberPPC()-1))
						{
								System.out.println("--> Try again: (Enter number 0 to " + (arr1[posNumber].getNumberPPC()-1)+ "): ");
								index = in.nextInt();	
						}
					}
					while(index <0 || index >(arr1[posNumber].getNumberPPC()-1));
					
					if (arr1[posNumber].removePPC(index) == false)
						System.out.println("Sorry, PrePaiCard was not successful");
					else
						System.out.println("PrePaiCard was removed successfully");
					
					System.out.println();
				}
			}
			else if (userInput == 8)//asks the user which prepaid card from which PoS they want to update; ask for new expiry date and update
			{
				System.out.print("Which PoS do you want to update a PrePaiCard from? (Enter number 0 to " + (arr1.length-1) +"): ");
				int pos = in.nextInt();
				
				if(arr1[pos].getNumberPPC() == 0)
					System.out.println("There are no PrePaiCards to update here");
				else
				{
					System.out.println("Which PrePaiCard do you want to update? (Enter number 0 to " + (arr1[pos].getNumberPPC()-1) + "):");
					int ppc = in.nextInt();
					
					System.out.print("--> Enter new expiry date day number and month (separate by a space): ");
					int day = in.nextInt();
					int month = in.nextInt();
					
					arr1[pos].updateExpiryDate(day, month, ppc);
					
					System.out.println("Expiry Date updated.");
				}
			}
			else if(userInput ==9)
			{
				System.out.print("Which PoS do you want to add Sales to? (Enter number 0 to " + (arr1.length-1) + "): ");
				int posNumber = in.nextInt();
				do
				{
					if (posNumber <0 || posNumber >(arr1.length-1))
					{
							System.out.print("--> Try again: (Enter number 0 to " + (arr1.length-1) + "): ");
							posNumber = in.nextInt();	
					}
				}
				while(posNumber <0 || posNumber >(arr1.length-1));
				
				System.out.print("Enter 5 numbers (separated by a space): ");
				int junior = in.nextInt();
				int teen = in.nextInt();
				int medium = in.nextInt();
				int big = in.nextInt();
				int family = in.nextInt();
				
				System.out.println(arr1[posNumber].NewTotalMealSales(junior, teen, medium, big, family));
			}
			else if(userInput == 0)
			{
				break;
			}
			
			if(userInput<=0 && userInput>9)
				System.out.println("Sorry that is not a valid choice. Try again.");
				
			
		}
		while(userInput !=0 && userInput>0 && userInput<10);
		
		System.out.print("Thank you for using Concordia CostLessBites Catering Sales Counter Application !");
		System.exit(0);
		
		in.close();
	}

}
